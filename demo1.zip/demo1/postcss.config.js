module.exports = {
  plugins: {
    autoprefixer: {}
  }
};
