import Vue from "vue";
import PerfectScrollbar from "vue2-perfect-scrollbar";

// Perfect scrollbar
Vue.use(PerfectScrollbar);
