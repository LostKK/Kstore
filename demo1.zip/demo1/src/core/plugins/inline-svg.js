import Vue from "vue";
import { InlineSvgPlugin } from "vue-inline-svg";

Vue.use(InlineSvgPlugin);
